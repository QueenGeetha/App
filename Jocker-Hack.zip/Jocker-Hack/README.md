# Joker
This tool is  Joker powerful  virus tool  🔥 don't executed this tool your personal android phone 

i am Karthick form Chennai 
basically I'm computer science engineering 
i love hacking , i know hacking 

i love my India ❤️ 

my instagram I'd  : mr_rkarthik


my telegram id : @Drak24Evil



⚡ Installation method ⚡

Support as this tool

I am using script language 😈 

# termux 


pkg update -y && pkg upgrade 

pkg install git -y

git clone  https://github.com/mrkarthick-cool/Jocker.git

cd j@Ckér

chmod +x J@ckér.sh

./J@ckér.sh


#note this important 
video tutorials and YouTube channel

=======================

⚡Powerful virus tool for Android phone  ⚡

=======================

https://youtu.be/p8wD_GOByd0

GitHub Link

 https://github.com/mrkarthick-cool

☠️ Installation method  ☠️

Support as this tool

I am using script language 😈 


Support as kali linux , parrot linux , more 

# For kali  

apt update -y && apt upgrade 

apt install git -y

git clone  https://github.com/mrkarthick-cool/Jocker.git

cd j@Ckér

chmod +x J@ckér.sh

./J@ckér.sh

 Hello friends Support this tool just forward ⏩ 

With your friends and family
